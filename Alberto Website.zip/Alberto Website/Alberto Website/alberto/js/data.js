
// ALBERTO WATCH COLLECTION - PRODUCT DATA

var PRODUCTS = [

  // ===== VINTAGE WATCHES =====

  {
    id: 1,
    name: "Heritage Pocket 1920",
    brand: "Bulova",
    cat: "Vintage",
    price: 1250,
    img: "images/v1.jpg",
    desc: "Hand-wound pocket watch with Roman numerals and brass case.",
    specs: ["Manual wind", "Brass case 48mm", "Enamel dial"]
  },
  {
    id: 2,
    name: "Classic Automatic 58",
    brand: "Seiko",
    cat: "Vintage",
    price: 890,
    img: "images/v2.jpg",
    desc: "Mid-century dress watch on genuine leather strap.",
    specs: ["Automatic", "36mm", "Leather strap"]
  },
  {
    id: 3,
    name: "Railroad Chronometer",
    brand: "Bulova",
    cat: "Vintage",
    price: 1640,
    img: "images/v3.jpg",
    desc: "Restored railroad-grade timepiece with classic styling.",
    specs: ["21 jewels", "Gold-filled", "Restored 2025"]
  },
  {
    id: 11,
    name: "Heritage Roman Classic",
    brand: "Timex",
    cat: "Vintage",
    price: 320,
    img: "images/v4.jpg",
    desc: "Vintage-style watch with Roman numerals and a leather strap.",
    specs: ["Quartz movement", "Roman numeral dial", "Leather strap"]
  },
  {
    id: 12,
    name: "Retro Silver Automatic",
    brand: "Orient",
    cat: "Vintage",
    price: 580,
    img: "images/v5.jpg",
    desc: "Retro-inspired automatic watch with a polished silver case.",
    specs: ["Automatic movement", "Silver-tone case", "Classic dial"]
  },
  {
    id: 18,
    name: "Minimal White Dial",
    brand: "Daniel Wellington",
    cat: "Vintage",
    price: 280,
    img: "images/v6.jpg",
    desc: "Minimalist dress watch with a clean white dial.",
    specs: ["Minimal dial", "Slim case", "Leather strap"]
  },
  {
    id: 20,
    name: "Classic Mesh Silver",
    brand: "Fossil",
    cat: "Vintage",
    price: 350,
    img: "images/v7.jpg",
    desc: "Elegant silver watch with a mesh bracelet.",
    specs: ["Silver-tone case", "Mesh bracelet", "Minimal dial"]
  },
  {
    id: 21,
    name: "Classic Mesh Silver II",
    brand: "Fossil",
    cat: "Vintage",
    price: 458,
    img: "images/v8.jpg",
    desc: "Elegant silver watch with a mesh bracelet.",
    specs: ["Silver-tone case", "Mesh bracelet", "Minimal dial"]
  },

  // ===== LUXURY WATCHES =====

  {
    id: 4,
    name: "Oyster Datejust Gold",
    brand: "Rolex",
    cat: "Luxury",
    price: 38500,
    img: "images/v9.jpg",
    desc: "Gold watch with a fluted bezel and elegant bracelet.",
    specs: ["Date display", "Gold-tone finish", "Metal bracelet"]
  },
  {
    id: 5,
    name: "Two-Tone Chronograph",
    brand: "Michael Kors",
    cat: "Luxury",
    price: 450,
    img: "images/v10.jpg",
    desc: "Bold two-tone chronograph with a tachymeter-style bezel.",
    specs: ["Quartz chrono", "44mm", "Stainless steel and gold-tone finish"]
  },
  {
    id: 6,
    name: "Eco-Drive Signature",
    brand: "Citizen",
    cat: "Luxury",
    price: 1290,
    img: "images/v11.jpg",
    desc: "Light-powered watch with refined styling.",
    specs: ["Eco-Drive", "Sapphire crystal", "Calendar"]
  },
  {
    id: 7,
    name: "Precisionist Grand",
    brand: "Bulova",
    cat: "Luxury",
    price: 795,
    img: "images/v12.jpg",
    desc: "Bold precision-inspired watch with a sporty design.",
    specs: ["Precisionist movement", "46mm", "Sporty bezel"]
  },
  {
    id: 13,
    name: "Royal Blue Prestige",
    brand: "Tissot",
    cat: "Luxury",
    price: 950,
    img: "images/v13.jpg",
    desc: "Sophisticated watch with a deep blue dial and steel bracelet.",
    specs: ["Blue dial", "Stainless steel style", "Date display"]
  },
  {
    id: 14,
    name: "Diamond Elite Gold",
    brand: "Fossil",
    cat: "Luxury",
    price: 520,
    img: "images/v14.jpg",
    desc: "Gold-tone watch with decorative crystal accents.",
    specs: ["Gold-tone case", "Crystal accents", "Metal bracelet"]
  },
  {
    id: 17,
    name: "Midnight Steel Diver",
    brand: "Seiko",
    cat: "Luxury",
    price: 690,
    img: "images/v15.jpg",
    desc: "Sporty dark watch with a dive-style bezel.",
    specs: ["Black dial", "Steel bracelet", "Dive-style bezel"]
  },
  {
    id: 19,
    name: "Sport Chrono Black",
    brand: "Casio",
    cat: "Luxury",
    price: 180,
    img: "images/v16.jpg",
    desc: "Sporty black chronograph-style watch.",
    specs: ["Sport design", "Black finish", "Chronograph style"]
  },

  // ===== SMART WATCHES =====

  {
    id: 8,
    name: "Galaxy Watch 7",
    brand: "Alberto Tech",
    cat: "Smart",
    price: 299,
    img: "images/v17.jpg",
    desc: "Fitness smartwatch with AMOLED display and GPS features.",
    specs: ["Heart-rate tracking", "GPS", "7-day battery target"]
  },
  {
    id: 9,
    name: "Huawei Watch GT 5 Pro",
    brand: "Michael Kors",
    cat: "Smart",
    price: 355,
    img: "images/v18.jpg",
    desc: "Fashion-inspired hybrid smartwatch.",
    specs: ["Hybrid smart features", "Notifications", "Rechargeable battery"]
  },
  {
    id: 10,
    name: "Redmi Watch 5",
    brand: "Citizen",
    cat: "Smart",
    price: 425,
    img: "images/v19.jpg",
    desc: "Modern touchscreen watch with classic styling.",
    specs: ["Touchscreen", "Sleep tracking", "Activity tracking"]
  },
  {
    id: 15,
    name: "Nova AMOLED Pro",
    brand: "Alberto Tech",
    cat: "Smart",
    price: 199,
    img: "images/v20.jpg",
    desc: "Modern smartwatch with a vibrant display and customizable faces.",
    specs: ["AMOLED display", "Bluetooth notifications", "Activity tracking"]
  },
  {
    id: 16,
    name: "FitTrack Ultra",
    brand: "Alberto Tech",
    cat: "Smart",
    price: 249,
    img: "images/v21.jpg",
    desc: "Sporty smartwatch designed for everyday fitness tracking.",
    specs: ["Step counter", "Workout modes", "Sleep tracking"]
  },
  {
    id: 22,
    name: "Galaxy AMOLED X",
    brand: "Alberto Tech",
    cat: "Smart",
    price: 249,
    img: "images/v22.jpg",
    desc: "Premium smartwatch with a bright AMOLED screen, fitness tracking, and smart notifications.",
    specs: ["AMOLED display", "Bluetooth calling", "Heart rate monitoring"]
  },
  {
    id: 23,
    name: "Titan Smart Fit",
    brand: "Alberto Tech",
    cat: "Smart",
    price: 179,
    img: "images/v23.jpg",
    desc: "Stylish fitness smartwatch designed for everyday use, workouts, and activity tracking.",
    specs: ["Full touch display", "Step and sleep tracking", "Multiple sports modes"]
  },
  {
    id: 24,
    name: "Ultra Smart Pro",
    brand: "Alberto Tech",
    cat: "Smart",
    price: 299,
    img: "images/v24.jpg",
    desc: "Modern premium smartwatch featuring a large display, customizable watch faces, and convenient smart features.",
    specs: ["Large HD display", "Bluetooth notifications", "Water-resistant design"]
  }

];
