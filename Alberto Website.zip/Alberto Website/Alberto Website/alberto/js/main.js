$(function () {
  // Preloader
  $(window).on('load', function () { $('#preloader').fadeOut(700); });
  setTimeout(function () { $('#preloader').fadeOut(700); }, 2500);

  // Visitor counter (localStorage)
  var count = parseInt(localStorage.getItem('albertoVisits') || '1250', 10) + 1;
  localStorage.setItem('albertoVisits', count);
  $({ n: 0 }).animate({ n: count }, { duration: 1500, step: function (v) { $('#visitorCount').text(Math.floor(v).toLocaleString()); } });

  // Navbar scroll + menu click color + fade
  $(window).on('scroll', function () {
    var s = $(this).scrollTop();
    $('#mainNav').toggleClass('scrolled', s > 60);
    s > 400 ? $('#toTop').fadeIn() : $('#toTop').fadeOut();
    reveal();
  });
  $('.nav-link').on('click', function () {
    $('.nav-link').removeClass('clicked');
    $(this).addClass('clicked');
    $('.navbar-collapse').collapse('hide');
  });
  $('#navMenu .nav-item').hide().each(function (i) { $(this).delay(150 * i).fadeIn(500); });
  $('#toTop').on('click', function () { $('html,body').animate({ scrollTop: 0 }, 600); });

  // Scroll reveal
  function reveal() {
    var wb = $(window).scrollTop() + $(window).height() - 60;
    $('.reveal').each(function () { if ($(this).offset().top < wb) $(this).addClass('visible'); });
  }
  reveal();

  // Products
  function render(cat) {
    var list = cat === 'All' ? PRODUCTS : PRODUCTS.filter(function (p) { return p.cat === cat; });
    var $g = $('#productGrid').hide().empty();
    list.forEach(function (p) {
      $g.append('<div class="col-sm-6 col-lg-3"><div class="p-card" data-id="' + p.id + '" role="button">' +
        '<div class="img-box"><img src="' + p.img + '" alt="' + p.name + '" loading="lazy"></div>' +
        '<div class="body"><span class="tag">' + p.brand + ' · ' + p.cat + '</span><h5>' + p.name + '</h5>' +
        '<span class="price">$' + p.price.toLocaleString() + '</span></div></div></div>');
    });
    $g.fadeIn(500);
  }
  render('All');
  $('.filter-btn').on('click', function () {
    $('.filter-btn').removeClass('active'); $(this).addClass('active');
    render($(this).data('cat'));
  });
  $('.line-card').on('click', function () {
    var c = $(this).data('cat');
    $('.filter-btn[data-cat="' + c + '"]').trigger('click');
    $('html,body').animate({ scrollTop: $('.filters').offset().top - 90 }, 600);
  });

  // Modal
  var modal = new bootstrap.Modal('#productModal');
  function openProduct(id) {
    var p = PRODUCTS.find(function (x) { return x.id == id; });
    $('#mTitle').text(p.name); $('#mImg').attr('src', p.img).attr('alt', p.name);
    $('#mBrand').text(p.brand + ' · ' + p.cat); $('#mDesc').text(p.desc);
    $('#mSpecs').html(p.specs.map(function (s) { return '<li>' + s + '</li>'; }).join(''));
    $('#mPrice').text('$' + p.price.toLocaleString());
    modal.show();
  }
  $(document).on('click', '.p-card, .price-table tbody tr', function () { openProduct($(this).data('id')); });

  // Price list
  PRODUCTS.forEach(function (p, i) {
    $('#priceBody').append('<tr data-id="' + p.id + '"><td>' + (i + 1) + '</td><td>' + p.name + '</td><td>' + p.brand + '</td><td>' + p.cat + '</td><td class="text-end gold">$' + p.price.toLocaleString() + '</td></tr>');
  });

  // Counters
  var counted = false;
  $(window).on('scroll', function () {
    if (counted || $('.stats').offset().top > $(window).scrollTop() + $(window).height()) return;
    counted = true;
    $('.counter').each(function () {
      var $t = $(this);
      $({ n: 0 }).animate({ n: $t.data('to') }, { duration: 2000, step: function (v) { $t.text(Math.floor(v).toLocaleString() + '+'); } });
    });
  });

  // Support form
  $('#supportForm').on('submit', function (e) { e.preventDefault(); $('#formMsg').fadeIn().delay(3000).fadeOut(); this.reset(); });

  // Ticker: date, time, location
  var loc = 'Detecting location…';
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function (pos) {
      loc = 'Lat ' + pos.coords.latitude.toFixed(4) + ', Lng ' + pos.coords.longitude.toFixed(4);
    }, function () { loc = 'Location unavailable'; });
  } else { loc = 'Geolocation not supported'; }
  function tick() {
    var d = new Date();
    $('#heroTime').text(d.toLocaleTimeString());
    $('#ticker').html('<i class="bi bi-calendar3"></i> ' + d.toDateString() + ' &nbsp;&nbsp;•&nbsp;&nbsp; <i class="bi bi-clock"></i> ' + d.toLocaleTimeString() +
      ' &nbsp;&nbsp;•&nbsp;&nbsp; <i class="bi bi-geo-alt"></i> ' + loc + ' &nbsp;&nbsp;•&nbsp;&nbsp; Welcome to Alberto Watch Company — Luxury Timepieces, Repair & Appraisal');
  }
  tick(); setInterval(tick, 1000);
});
