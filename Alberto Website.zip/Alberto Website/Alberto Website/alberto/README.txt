ALBERTO WATCH COMPANY - Single Page Website
==========================================
Tech: HTML5, CSS3, Bootstrap 5, JavaScript, jQuery, Bootstrap Icons, Google Fonts (Cormorant Garamond + Montserrat).

HOW TO RUN: Open index.html in Chrome/Edge/Firefox/Safari (internet needed for CDN libraries).

FEATURES
- Logo + visitor count (top right, stored in browser)
- Menu: Products, Technology, Price List, Gallery, Store Locator, Support, About, Contact
- Menu color change on hover/click, fade-in menu
- Product line-ups: Vintage, Luxury, Smart Watches (click to filter)
- Product details in popup (modal); price list table
- Gallery, Site map (footer), About & Contact (email, address, phone)
- Scrolling ticker at bottom with date, time & geolocation
- Animations: preloader, scroll reveal, hover zoom, counters

DATA: js/data.js and data/products.json

ASSUMPTIONS: Contact details and prices are sample data. Geolocation requires the user's permission.
